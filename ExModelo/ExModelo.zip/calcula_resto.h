#ifndef CALCULA_RESTO_H
#define CALCULA_RESTO_H
unsigned char calcula_resto(void);
#endif
