#ifndef NOVES_FORA_H
#define NOVES_FORA_H
void noves_fora(unsigned int *numeros, int n);
#endif
